package com.vov.pojos;

public class Billing {
	private String cemail;
	private String spemail;
	private String msg;
	
	public String getCemail() {
		return cemail;
	}
	public void setCemail(String cemail) {
		this.cemail = cemail;
	}
	public String getSpemail() {
		return spemail;
	}
	public void setSpemail(String spemail) {
		this.spemail = spemail;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
